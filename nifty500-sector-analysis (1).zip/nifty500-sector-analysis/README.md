# NIFTY500 Sector Analysis (Intraday 09:15-12:15 IST)

**Author:** Ashish Yadav

## Overview
This project identifies the top 3 gaining and top 3 losing sectors within the NIFTY 500 index during the first half of the trading session (09:15 AM to 12:15 PM IST) for a chosen date.

The repository includes:
- `fetch_nifty500_list.py` — scrapes NIFTY 500 constituents & sectors from the NSE website and saves `nifty500_stocks.csv`.
- `analyze_intraday_first_half.py` — downloads 1-minute intraday data (via Yahoo Finance), extracts prices at 09:15 and 12:15 IST, computes percentage changes per stock, groups by sector, and outputs top sectors.
- `requirements.txt` — Python dependencies.
- `sample_output/` — small sample CSVs (example outputs).

## How to run (example)
1. Clone the repo and install requirements:
   ```bash
   pip install -r requirements.txt
   ```

2. Fetch NIFTY 500 constituents:
   ```bash
   python fetch_nifty500_list.py
   ```

3. Analyze intraday performance for a date (YYYY-MM-DD):
   ```bash
   python analyze_intraday_first_half.py --date 2025-10-24
   ```

If `--date` is omitted, the script will use today's date (IST).

## Notes & Caveats
- The scripts use the NSE public endpoint to fetch the index constituents and use Yahoo Finance (via `yfinance`) for minute-level intraday prices.
- Minute-level data availability depends on Yahoo's coverage; if minute bars are missing, the script logs failures to `failures_<date>.csv`.
- All fetched raw minute files are saved into `raw_minute_data/` for auditing.
- For strict NSE-only scraping of minute bars, a Selenium-based approach would be needed (not included).

## Deliverable
This project is ready to push to a public GitHub repository. Reviewers can clone the repo, run the two scripts, and find CSV outputs in the working directory.

**Prepared for:** Freshers coding challenge / company submission
**Author:** Ashish Yadav
