# analyze_intraday_first_half.py
# Usage example:
# python analyze_intraday_first_half.py --date 2025-10-24
# If no --date provided, it uses today's date.

import pandas as pd
import yfinance as yf
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
import argparse
from dateutil import tz
from tqdm import tqdm
import os

WORKERS = 12
RAW_DIR = "raw_minute_data"
os.makedirs(RAW_DIR, exist_ok=True)

def load_constituents(csv_file="nifty500_stocks.csv"):
    df = pd.read_csv(csv_file)
    # drop duplicates and NA symbols
    df = df.dropna(subset=["symbol"]).drop_duplicates(subset=["symbol"])
    return df

def fetch_prices_for_symbol(yahoo_symbol, date_str):
    try:
        start = date_str
        end = (datetime.strptime(date_str, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
        df = yf.download(tickers=yahoo_symbol, start=start, end=end, interval="1m", progress=False, threads=False)
        if df.empty:
            return yahoo_symbol, None, None, "empty_data"

        raw_path = f"{RAW_DIR}/{yahoo_symbol.replace('/', '_')}_{date_str}.csv"
        df.to_csv(raw_path)

        df = df.tz_convert("Asia/Kolkata") if df.index.tzinfo else df.tz_localize("UTC").tz_convert("Asia/Kolkata")

        def price_at_or_nearest(ts_str):
            target = datetime.strptime(f"{date_str} {ts_str}", "%Y-%m-%d %H:%M").replace(tzinfo=tz.gettz("Asia/Kolkata"))
            if target in df.index:
                return float(df.loc[target]["Adj Close"])
            nearest_idx = df.index.get_indexer([target], method="nearest")[0]
            if nearest_idx == -1:
                return None
            nearest_ts = df.index[nearest_idx]
            if abs((nearest_ts - target).total_seconds()) <= 3 * 60:
                return float(df.iloc[nearest_idx]["Adj Close"])
            return None

        p0915 = price_at_or_nearest("09:15")
        p1215 = price_at_or_nearest("12:15")

        return yahoo_symbol, p0915, p1215, None
    except Exception as e:
        return yahoo_symbol, None, None, str(e)

def main(date_str):
    df_stocks = load_constituents()
    results = []
    failures = []

    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futures = {ex.submit(fetch_prices_for_symbol, row['yahoo_symbol'], date_str): row for _, row in df_stocks.iterrows()}
        for fut in tqdm(as_completed(futures), total=len(futures)):
            row = futures[fut]
            try:
                yahoo_symbol, p0915, p1215, err = fut.result()
                if err:
                    failures.append({"symbol": row['symbol'], "yahoo_symbol": yahoo_symbol, "error": err})
                    continue
                if p0915 is None or p1215 is None:
                    failures.append({"symbol": row['symbol'], "yahoo_symbol": yahoo_symbol, "error": "missing_timestamp_price"})
                    continue
                pct_change = (p1215 - p0915) / p0915 * 100
                results.append({"symbol": row['symbol'], "yahoo_symbol": yahoo_symbol, "sector": row['sector'], "p0915": p0915, "p1215": p1215, "pct_change": pct_change})
            except Exception as e:
                failures.append({"symbol": row.get("symbol"), "error": str(e)})

    res_df = pd.DataFrame(results)
    if res_df.empty:
        print("No successful symbols fetched.")
        return

    sector_df = res_df.groupby("sector")["pct_change"].mean().reset_index().rename(columns={"pct_change": "avg_pct_change"})
    sector_df = sector_df.dropna(subset=["sector"]).sort_values("avg_pct_change", ascending=False)

    top_gainers = sector_df.head(3)
    top_losers = sector_df.tail(3)

    print("\n📈 Top 3 Gaining Sectors:")
    print(top_gainers.to_string(index=False))

    print("\n📉 Top 3 Losing Sectors:")
    print(top_losers.to_string(index=False))

    res_df.to_csv(f"intraday_stock_changes_{date_str}.csv", index=False)
    sector_df.to_csv(f"sector_avg_changes_{date_str}.csv", index=False)
    if failures:
        pd.DataFrame(failures).to_csv(f"failures_{date_str}.csv", index=False)
        print(f"\n⚠️ {len(failures)} symbols failed or missing data. See failures_{date_str}.csv")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", help="Date in YYYY-MM-DD (default today IST)", default=None)
    args = parser.parse_args()
    if args.date:
        date_str = args.date
    else:
        ist_now = datetime.now(tz=tz.gettz("Asia/Kolkata"))
        date_str = ist_now.strftime("%Y-%m-%d")
    print(f"Running intraday analysis for {date_str} (09:15-12:15 IST)")
    main(date_str)
